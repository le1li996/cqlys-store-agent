// 门店经营智脑 · 后端服务（单文件，零原生依赖）
// ============================================================
// 提供：手机号验证码注册/登录、文件上传下载。
// 存储：JSON 文件 (server/db.json) —— 原型足够真实；生产可换 SQLite/Postgres，
//       仅需替换本文件底部 db 读写函数，路由逻辑不变。
// 短信：SMS provider 抽象。默认 dev（验证码回显到服务端日志，不发真短信）；
//       配置 TENCENT_* 环境变量 + SMS_PROVIDER=tencent 即走腾讯云短信真实下发。
//
// 启动：node server/index.mjs   （默认端口 8787）
// 生产：本服务同时托管 dist 静态文件，部署到能跑 Node 的环境即全栈可用。
// ============================================================

import express from 'express'
import cors from 'cors'
import multer from 'multer'
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'
import 'dotenv/config'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ROOT = path.resolve(__dirname, '..')
const DIST = path.join(ROOT, 'dist')
const UPLOAD_DIR = path.join(__dirname, 'uploads')
const DB_FILE = path.join(__dirname, 'db.json')
const PORT = process.env.PORT || 8787

fs.mkdirSync(UPLOAD_DIR, { recursive: true })
if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(DB_FILE, JSON.stringify({ users: [], codes: [], tokens: [], files: [] }, null, 2))
}

// ---------- 文件型 DB ----------
const readDB = () => JSON.parse(fs.readFileSync(DB_FILE, 'utf8'))
const writeDB = (db) => fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2))

// ---------- 密码哈希（Node crypto.scrypt，零依赖） ----------
function hashPassword(pw, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(pw, salt, 64).toString('hex')
  return { salt, hash }
}
function verifyPassword(pw, salt, hash) {
  const h = crypto.scryptSync(pw, salt, 64).toString('hex')
  return crypto.timingSafeEqual(Buffer.from(h, 'hex'), Buffer.from(hash, 'hex'))
}

const newToken = () => crypto.randomBytes(24).toString('hex')
const newId = (p) => p + crypto.randomBytes(8).toString('hex')
const genCode = () => String(Math.floor(100000 + Math.random() * 900000))

// ---------- 鉴权中间件 ----------
function auth(req, res, next) {
  const h = req.headers.authorization || ''
  const t = h.startsWith('Bearer ') ? h.slice(7) : req.query.token || ''
  if (!t) return res.status(401).json({ ok: false, error: '未登录' })
  const db = readDB()
  const tk = db.tokens.find((x) => x.token === t)
  if (!tk) return res.status(401).json({ ok: false, error: '登录失效，请重新登录' })
  const user = db.users.find((u) => u.id === tk.userId)
  if (!user) return res.status(401).json({ ok: false, error: '用户不存在' })
  req.user = user
  next()
}

function publicAccount(u) {
  return { id: u.id, phone: u.phone, name: u.phone.slice(0, 3) + '****' + u.phone.slice(7), plan: u.plan, createdAt: u.createdAt }
}

// ---------- 短信 provider ----------
const sha256 = (m) => crypto.createHash('sha256').update(m, 'utf8').digest('hex')
const hmac = (key, m) => crypto.createHmac('sha256', key).update(m, 'utf8').digest()

async function sendTencentSms(phone, code) {
  const secretId = process.env.TENCENT_SECRET_ID
  const secretKey = process.env.TENCENT_SECRET_KEY
  const host = 'sms.tencentcloudapi.com'
  const service = 'sms'
  const action = 'SendSms'
  const version = '2021-01-11'
  const region = process.env.TENCENT_REGION || 'ap-guangzhou'
  const algorithm = 'TC3-HMAC-SHA256'

  const payload = JSON.stringify({
    PhoneNumberSet: ['+86' + phone],
    SmsSdkAppId: process.env.TENCENT_SMS_APP_ID,
    SignName: process.env.TENCENT_SIGN_NAME,
    TemplateId: process.env.TENCENT_TEMPLATE_ID,
    TemplateParamSet: [code],
  })

  const timestamp = Math.floor(Date.now() / 1000)
  const date = new Date(timestamp * 1000).toISOString().slice(0, 10)
  const hashedPayload = sha256(payload)
  const canonicalHeaders = 'content-type:application/json; charset=utf-8\nhost:' + host + '\n'
  const signedHeaders = 'content-type;host'
  const canonicalRequest = [
    'POST', '/', '', canonicalHeaders, signedHeaders, hashedPayload,
  ].join('\n')
  const credentialScope = `${date}/${service}/tc3_request`
  const stringToSign = [algorithm, timestamp, credentialScope, sha256(canonicalRequest)].join('\n')
  const secretDate = hmac('TC3' + secretKey, date)
  const secretService = hmac(secretDate, service)
  const secretSigning = hmac(secretService, 'tc3_request')
  const signature = crypto.createHmac('sha256', secretSigning).update(stringToSign, 'utf8').digest('hex')
  const authorization = `${algorithm} Credential=${secretId}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`

  const headers = {
    Authorization: authorization,
    'Content-Type': 'application/json; charset=utf-8',
    Host: host,
    'X-TC-Action': action,
    'X-TC-Version': version,
    'X-TC-Timestamp': String(timestamp),
    'X-TC-Region': region,
  }
  const resp = await fetch(`https://${host}`, { method: 'POST', headers, body: payload })
  const json = await resp.json()
  if (json.Response && json.Response.Error) throw new Error(json.Response.Error.Message)
  return { dev: false }
}

const SMS = {
  provider: process.env.SMS_PROVIDER || 'dev',
  async send(phone, code) {
    const hasCred = process.env.TENCENT_SECRET_ID && process.env.TENCENT_SECRET_KEY && process.env.TENCENT_SMS_APP_ID
    if (this.provider === 'tencent' && hasCred) {
      try {
        await sendTencentSms(phone, code)
        console.log(`[SMS] 已向 ${phone} 真实下发验证码`)
        return { dev: false }
      } catch (e) {
        console.error('[SMS] 腾讯云下发失败，降级 dev 回显：', e.message)
      }
    }
    console.log(`[DEV-SMS] 给 ${phone} 的验证码：${code}`)
    return { dev: true }
  },
}

// ---------- Express ----------
const app = express()
app.use(cors())
app.use(express.json())

// —— 健康检查 ——
app.get('/api/health', (req, res) => res.json({ ok: true, sms: SMS.provider }))

// —— 发送验证码 ——
app.post('/api/auth/send-code', async (req, res) => {
  const { phone } = req.body || {}
  if (!/^1\d{10}$/.test(phone || '')) return res.status(400).json({ ok: false, error: '请输入有效的 11 位手机号' })
  const db = readDB()
  const recent = db.codes.find((c) => c.phone === phone && c.expiresAt > Date.now())
  if (recent) {
    const wait = Math.ceil((recent.expiresAt - Date.now()) / 1000)
    return res.status(429).json({ ok: false, error: `请 ${wait}s 后再获取验证码` })
  }
  const code = genCode()
  db.codes = db.codes.filter((c) => c.phone !== phone)
  db.codes.push({ phone, code, expiresAt: Date.now() + 5 * 60 * 1000 })
  writeDB(db)
  const r = await SMS.send(phone, code)
  // 生产环境绝不回显验证码；dev 模式返回便于本地测试
  res.json({ ok: true, devCode: r.dev ? code : undefined })
})

// —— 注册（手机号 + 验证码 + 密码）——
app.post('/api/auth/register', (req, res) => {
  const { phone, code, password } = req.body || {}
  if (!/^1\d{10}$/.test(phone || '')) return res.status(400).json({ ok: false, error: '手机号格式不正确' })
  if (!code || !/^\d{6}$/.test(code)) return res.status(400).json({ ok: false, error: '请输入 6 位验证码' })
  if (!password || password.length < 6) return res.status(400).json({ ok: false, error: '密码至少 6 位' })
  const db = readDB()
  const rec = db.codes.find((c) => c.phone === phone)
  if (!rec || rec.expiresAt < Date.now()) return res.status(400).json({ ok: false, error: '验证码已过期，请重新获取' })
  if (rec.code !== code) return res.status(400).json({ ok: false, error: '验证码不正确' })
  if (db.users.find((u) => u.phone === phone)) return res.status(409).json({ ok: false, error: '该手机号已注册，请直接登录' })

  const { salt, hash } = hashPassword(password)
  const user = {
    id: newId('u'), phone, salt, hash,
    name: phone.slice(0, 3) + '****' + phone.slice(7),
    plan: '试用版', createdAt: new Date().toISOString(),
  }
  db.users.push(user)
  db.codes = db.codes.filter((c) => c.phone !== phone)
  const token = newToken()
  db.tokens.push({ token, userId: user.id, createdAt: new Date().toISOString() })
  writeDB(db)
  res.json({ ok: true, token, account: publicAccount(user) })
})

// —— 登录（手机号 + 密码）——
app.post('/api/auth/login', (req, res) => {
  const { phone, password } = req.body || {}
  if (!/^1\d{10}$/.test(phone || '')) return res.status(400).json({ ok: false, error: '手机号格式不正确' })
  const db = readDB()
  const user = db.users.find((u) => u.phone === phone)
  if (!user) return res.status(404).json({ ok: false, error: '账号不存在，请先注册' })
  if (!verifyPassword(password, user.salt, user.hash)) return res.status(401).json({ ok: false, error: '密码不正确' })
  const token = newToken()
  db.tokens.push({ token, userId: user.id, createdAt: new Date().toISOString() })
  writeDB(db)
  res.json({ ok: true, token, account: publicAccount(user) })
})

// —— 当前账号 ——
app.get('/api/auth/me', auth, (req, res) => res.json({ ok: true, account: publicAccount(req.user) }))

// —— 文件上传 ——
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).slice(0, 12)
    cb(null, newId('f') + ext)
  },
})
const upload = multer({ storage, limits: { fileSize: 20 * 1024 * 1024 } })

app.post('/api/files/upload', auth, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ ok: false, error: '未收到文件' })
  const db = readDB()
  const meta = {
    id: path.basename(req.file.filename, path.extname(req.file.filename)),
    name: req.file.originalname,
    size: req.file.size,
    mime: req.file.mimetype,
    ownerId: req.user.id,
    createdAt: new Date().toISOString(),
  }
  db.files.push(meta)
  writeDB(db)
  res.json({ ok: true, file: { id: meta.id, name: meta.name, size: meta.size, mime: meta.mime, url: `/api/files/${meta.id}` } })
})

// —— 文件下载 ——
app.get('/api/files/:id', auth, (req, res) => {
  const db = readDB()
  const meta = db.files.find((f) => f.id === req.params.id)
  if (!meta) return res.status(404).json({ ok: false, error: '文件不存在' })
  const filePath = path.join(UPLOAD_DIR, req.params.id + (path.extname(meta.name) ? '' : ''))
  // 文件名在磁盘上是 id+ext，需要从 meta 还原
  const onDisk = fs.readdirSync(UPLOAD_DIR).find((n) => n.startsWith(meta.id))
  if (!onDisk) return res.status(404).json({ ok: false, error: '文件已丢失' })
  res.download(path.join(UPLOAD_DIR, onDisk), meta.name)
})

// —— 托管前端静态资源（生产全栈同进程）——
if (fs.existsSync(DIST)) {
  app.use(express.static(DIST))
  app.use((req, res, next) => {
    if (req.path.startsWith('/api')) return next()
    if (req.method !== 'GET') return next()
    res.sendFile(path.join(DIST, 'index.html'))
  })
}

app.listen(PORT, () => {
  console.log(`[门店经营智脑] 后端已启动: http://localhost:${PORT}  (短信通道: ${SMS.provider})`)
})
